import { useState } from "react";
import OpportunityCard from "../opportunities/OpportunityCard";
import OpportunityDetail from "../opportunities/OpportunityDetail";
import { normalizeOpportunityAction } from "../../services/intelligence/opportunityActionNormalizer";
import { buildOpportunityFeed } from "../../services/intelligence/opportunityFeedEngine";

export default function OpportunityIntelligencePanel({ pipeline }) {
  const [selectedOpportunity, setSelectedOpportunity] = useState(null);

  if (!pipeline || pipeline.totalRecords === 0) {
    return (
      <div style={panelStyle}>
        <p style={eyebrowStyle}>FASE 10.9.3 · Shared Opportunity Feed</p>
        <h2 style={titleStyle}>🏆 Top oportunidades detectadas</h2>
        <p style={emptyTextStyle}>
          Todavía no hay suficientes registros para construir un ranking de oportunidades.
        </p>
      </div>
    );
  }

  const summary = pipeline.summary || {};
  const topItems = pipeline.topOpportunities || [];
  const feedItems = buildOpportunityFeed({
    radar: {
      priorityOpportunities: topItems.map(buildFeedOpportunityItem),
    },
    changes: pipeline.changes || [],
    alerts: pipeline.alerts || {},
    limit: 8,
  }).events;

  const bestOpportunity = topItems[0] || null;
  const bestCardOpportunity = bestOpportunity
    ? buildCardOpportunity(bestOpportunity)
    : null;

  return (
    <div style={panelStyle}>
      <div style={headerStyle}>
        <div>
          <p style={eyebrowStyle}>FASE 10.9.3 · Shared Opportunity Feed</p>
          <h2 style={titleStyle}>🏆 Top oportunidades detectadas</h2>
        </div>

        <strong style={badgeStyle}>
          {pipeline.buyCount || 0} BUY · {pipeline.watchCount || 0} WATCH ·{" "}
          {pipeline.rejectCount || 0} REJECT
        </strong>
      </div>

      {bestCardOpportunity && (
        <section style={heroSectionStyle}>
          <p style={heroEyebrowStyle}>Mejor oportunidad actual</p>
          <OpportunityCard
            opportunity={bestCardOpportunity}
            onOpen={setSelectedOpportunity}
          />

          {selectedOpportunity && (
            <section style={detailSectionStyle}>
              <p style={detailEyebrowStyle}>Explicación completa</p>
              <OpportunityDetail opportunity={selectedOpportunity} />
            </section>
          )}
        </section>
      )}

      {feedItems.length > 0 && (
        <section style={feedSectionStyle}>
          <p style={feedEyebrowStyle}>🔥 Opportunity Feed</p>

          <div style={feedGridStyle}>
            {feedItems.map((event, index) => (
              <div key={`${event.type}-${event.title}-${index}`} style={feedCardStyle}>
                <div>
                  <p style={feedTypeStyle}>{event.type}</p>
                  <strong style={feedTitleStyle}>{event.title}</strong>
                  <p style={feedTextStyle}>{event.text}</p>
                </div>

                <span style={feedPriorityStyle}>{event.priority}/100</span>
              </div>
            ))}
          </div>
        </section>
      )}

      <div style={gridStyle}>
        <MetricCard label="Vehículos analizados" value={summary.totalRecords || 0} />
        <MetricCard label="Capital requerido" value={`${formatNumber(summary.requiredCapital)} €`} />
        <MetricCard label="Beneficio potencial" value={`${formatNumber(summary.expectedProfit)} €`} />
        <MetricCard label="ROI medio" value={`${formatNumber(summary.averageROI)}%`} />
        <MetricCard label="Score V2 medio" value={`${formatNumber(summary.averageOpportunityScoreV2)}/100`} />
        <MetricCard label="Comparables" value={summary.totalComparables || 0} />
        <MetricCard label="Rotación media" value={`${formatNumber(summary.averageSellSpeedScore)}/100`} />
        <MetricCard label="Venta media" value={`${formatNumber(summary.averageEstimatedSellDays)} días`} />
      </div>

      {topItems.length === 0 ? (
        <p style={emptyTextStyle}>No hay oportunidades destacadas para mostrar todavía.</p>
      ) : (
        <div style={listStyle}>
          {topItems.slice(0, 10).map((item, index) => (
            <OpportunityRow
              key={item.id || `${item.brand}-${item.model}-${index}`}
              item={item}
              index={index}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function buildFeedOpportunityItem(item = {}) {
  const decision = item.decision || {};
  const valuation = item.valuation || {};
  const opportunity = item.opportunity || {};
  const vehicleValuation = item.vehicleValuation || {};
  const sellSpeed = item.sellSpeed || {};

  const action = normalizeOpportunityAction(
    decision.action ||
      decision.recommendation ||
      decision.label ||
      opportunity.opportunityLevelV2 ||
      item.action ||
      "WATCH"
  );

  const decisionScore =
    Number(
      decision.decisionScore ||
        opportunity.scoreV2 ||
        opportunity.opportunityScoreV2 ||
        item.score ||
        0
    ) || 0;

  const sellSpeedScore =
    Number(sellSpeed.sellSpeedScore || item.sellSpeedScore || 0) || 0;

  const discountPercent =
    Number(vehicleValuation.discountPercent || opportunity.discountPercent || 0) || 0;

  const roi = Number(valuation.roi ?? item.roi ?? 0) || 0;
  const profit = Number(valuation.profit ?? item.profit ?? 0) || 0;

  return {
    ...item,
    title: buildVehicleTitle(item),
    action,
    decisionScore,
    radarPriority: decisionScore,
    discoveryLevel: action === "BUY" && decisionScore >= 85 ? "DISCOVER_NOW" : "OBSERVE",
    sellSpeedScore,
    discountPercent,
    roi,
    profit,
  };
}

function buildCardOpportunity(item = {}) {
  const decision = item.decision || {};
  const valuation = item.valuation || {};
  const opportunity = item.opportunity || {};
  const vehicleValuation = item.vehicleValuation || {};
  const reasons = Array.isArray(opportunity.opportunityReasonsV2)
    ? opportunity.opportunityReasonsV2
    : [];

  const action = normalizeOpportunityAction(
    decision.action ||
      decision.recommendation ||
      decision.label ||
      opportunity.opportunityLevelV2 ||
      "WATCH"
  );

  return {
    ...item,
    title: buildVehicleTitle(item),
    action,
    decision: {
      ...decision,
      action,
      reasons: decision.reasons || reasons,
      summary:
        decision.summary ||
        vehicleValuation.summary ||
        reasons[0] ||
        "Oportunidad detectada por señales combinadas de mercado.",
      confidence: {
        ...(decision.confidence || {}),
        score:
          decision.confidence?.score ??
          decision.confidenceScore ??
          vehicleValuation.confidence ??
          item.confidence ??
          0,
      },
    },
    price: item.price ?? item.purchasePrice ?? valuation.purchasePrice,
    estimatedMarketValue:
      vehicleValuation.estimatedMarketValue ??
      valuation.estimatedMarketValue ??
      item.estimatedMarketValue,
    profit: valuation.profit ?? item.profit ?? opportunity.expectedProfit,
    roi: valuation.roi ?? item.roi ?? opportunity.expectedROI,
    valuation,
    vehicleValuation,
    opportunity,
    comparables: item.comparables,
    sellSpeed: item.sellSpeed,
  };
}

function buildVehicleTitle(item = {}) {
  return (
    [item.brand, item.model, item.version, item.year].filter(Boolean).join(" ") ||
    item.title ||
    "Vehículo sin identificar"
  );
}

function OpportunityRow({ item, index }) {
  const decision = item.decision || {};
  const valuation = item.valuation || {};
  const opportunity = item.opportunity || {};
  const vehicleValuation = item.vehicleValuation || {};
  const comparables = item.comparables || {};
  const sellSpeed = item.sellSpeed || {};

  const executiveBuySignalScore = Number(item.executiveBuySignalScore || 0);
  const executiveBuySignalLabel = item.executiveBuySignalLabel || "SIN_DATO";
  const timelineMomentumScore = Number(item.timelineMomentumScore || 0);
  const timelineMomentumLabel = item.timelineMomentumLabel || "SIN_DATO";

  const scoreV2 =
    opportunity.scoreV2 ||
    opportunity.opportunityScoreV2 ||
    decision.decisionScore ||
    opportunity.opportunityScore ||
    0;

  const levelV2 = normalizeOpportunityAction(
    decision.action ||
      opportunity.opportunityLevelV2 ||
      decision.label ||
      "WATCH"
  );

  const reasons = Array.isArray(opportunity.opportunityReasonsV2)
    ? opportunity.opportunityReasonsV2
    : [];

  return (
    <div style={rowStyle}>
      <div style={rankStyle}>#{index + 1}</div>

      <div style={mainStyle}>
        <strong style={vehicleStyle}>{buildVehicleTitle(item)}</strong>

        <p style={summaryStyle}>
          {decision.summary || vehicleValuation.summary || "Sin resumen de decisión disponible."}
        </p>

        <div style={tagsStyle}>
          <span style={tagStyle}>ROI {formatNumber(valuation.roi ?? item.roi)}%</span>
          <span style={tagStyle}>Margen {formatNumber(valuation.profit ?? item.profit)} €</span>
          <span style={tagStyle}>
            Valor estimado {formatNumber(vehicleValuation.estimatedMarketValue)} €
          </span>
          <span style={tagStyle}>
            Descuento {formatNumber(vehicleValuation.discountPercent)}%
          </span>
          <span style={tagStyle}>
            Confianza {vehicleValuation.confidence || 0}/100
          </span>
          <span style={tagStyle}>
            Comparables {comparables.totalComparables || 0}
          </span>
          <span style={tagStyle}>
            Rotación {sellSpeed.speedLabel || "SIN_DATO"}
          </span>
          <span style={tagStyle}>
            Venta {sellSpeed.estimatedSellDays || 0} días
          </span>
          <span style={tagStyle}>
            Valoración {valuation.valuationLabel || "sin dato"}
          </span>
          <span style={tagStyle}>
            Ejecutiva {executiveBuySignalLabel} {formatNumber(executiveBuySignalScore)}/100
          </span>
          <span style={tagStyle}>
            Momentum {timelineMomentumLabel} {formatNumber(timelineMomentumScore)}/100
          </span>
        </div>

        {sellSpeed.summary && (
          <div style={sellSpeedStyle}>⚡ {sellSpeed.summary}</div>
        )}

        {reasons.length > 0 && (
          <div style={reasonsStyle}>
            {reasons.slice(0, 5).map((reason, reasonIndex) => (
              <div key={`${reason}-${reasonIndex}`} style={reasonStyle}>
                ✓ {reason}
              </div>
            ))}
          </div>
        )}
      </div>

      <div style={scoreBoxStyle}>
        <strong style={actionStyle}>{levelV2}</strong>
        <span style={scoreStyle}>{scoreV2}/100</span>
        <small style={scoreLabelStyle}>Score V2</small>

        <div style={speedBoxStyle}>
          <strong style={speedScoreStyle}>
            {formatNumber(sellSpeed.sellSpeedScore)}/100
          </strong>
          <small style={scoreLabelStyle}>Rotación</small>
        </div>
      </div>
    </div>
  );
}

function MetricCard({ label, value }) {
  return (
    <div style={metricCardStyle}>
      <p style={metricLabelStyle}>{label}</p>
      <strong style={metricValueStyle}>{value}</strong>
    </div>
  );
}

function formatNumber(value) {
  const numericValue = Number(value);

  if (!Number.isFinite(numericValue)) {
    return "0";
  }

  return numericValue.toLocaleString("es-ES", {
    maximumFractionDigits: 2,
  });
}

const panelStyle = {
  padding: "22px",
  borderRadius: "24px",
  background:
    "linear-gradient(135deg, rgba(15,23,42,0.92), rgba(30,41,59,0.72))",
  border: "1px solid rgba(250,204,21,0.28)",
  marginBottom: "28px",
};

const headerStyle = {
  display: "flex",
  justifyContent: "space-between",
  gap: "16px",
  alignItems: "flex-start",
  marginBottom: "18px",
  flexWrap: "wrap",
};

const eyebrowStyle = {
  margin: "0 0 6px 0",
  color: "#fde68a",
  fontSize: "12px",
  fontWeight: "900",
  letterSpacing: "0.08em",
  textTransform: "uppercase",
};

const titleStyle = {
  margin: 0,
  fontSize: "21px",
  fontWeight: "900",
};

const badgeStyle = {
  padding: "10px 14px",
  borderRadius: "999px",
  background: "rgba(250,204,21,0.14)",
  border: "1px solid rgba(250,204,21,0.3)",
  color: "#fef3c7",
  fontSize: "12px",
};

const heroSectionStyle = {
  marginBottom: "18px",
};

const heroEyebrowStyle = {
  margin: "0 0 10px 0",
  color: "#bbf7d0",
  fontSize: "13px",
  fontWeight: "950",
  letterSpacing: "0.05em",
  textTransform: "uppercase",
};

const detailSectionStyle = {
  marginTop: "18px",
};

const detailEyebrowStyle = {
  margin: "0 0 10px 0",
  color: "#93c5fd",
  fontSize: "13px",
  fontWeight: "950",
  letterSpacing: "0.05em",
  textTransform: "uppercase",
};

const feedSectionStyle = {
  marginBottom: "18px",
};

const feedEyebrowStyle = {
  margin: "0 0 10px 0",
  color: "#86efac",
  fontSize: "13px",
  fontWeight: "950",
  letterSpacing: "0.05em",
  textTransform: "uppercase",
};

const feedGridStyle = {
  display: "grid",
  gap: "10px",
  marginBottom: "18px",
};

const feedCardStyle = {
  display: "flex",
  justifyContent: "space-between",
  gap: "14px",
  alignItems: "flex-start",
  padding: "14px 16px",
  borderRadius: "18px",
  background: "rgba(34,197,94,0.10)",
  border: "1px solid rgba(34,197,94,0.22)",
};

const feedTypeStyle = {
  margin: "0 0 5px 0",
  color: "#86efac",
  fontSize: "11px",
  fontWeight: "950",
};

const feedTitleStyle = {
  display: "block",
  color: "#ffffff",
  fontSize: "15px",
  marginBottom: "5px",
};

const feedTextStyle = {
  margin: 0,
  color: "#d1fae5",
  fontSize: "12px",
  lineHeight: "1.45",
};

const feedPriorityStyle = {
  minWidth: "66px",
  textAlign: "center",
  padding: "7px 10px",
  borderRadius: "999px",
  background: "rgba(15,23,42,0.7)",
  color: "#bbf7d0",
  fontSize: "12px",
  fontWeight: "950",
};

const gridStyle = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit,minmax(180px,1fr))",
  gap: "14px",
  marginBottom: "18px",
};

const metricCardStyle = {
  padding: "16px",
  borderRadius: "18px",
  background: "rgba(2,6,23,0.45)",
  border: "1px solid rgba(148,163,184,0.18)",
};

const metricLabelStyle = {
  margin: 0,
  color: "#cbd5e1",
  fontSize: "12px",
  fontWeight: "800",
};

const metricValueStyle = {
  display: "block",
  marginTop: "8px",
  color: "#ffffff",
  fontSize: "22px",
};

const listStyle = {
  display: "grid",
  gap: "12px",
};

const rowStyle = {
  display: "grid",
  gridTemplateColumns: "54px 1fr auto",
  gap: "14px",
  alignItems: "center",
  padding: "16px",
  borderRadius: "18px",
  background: "rgba(15,23,42,0.66)",
  border: "1px solid rgba(148,163,184,0.18)",
};

const rankStyle = {
  width: "42px",
  height: "42px",
  borderRadius: "14px",
  display: "grid",
  placeItems: "center",
  background: "rgba(250,204,21,0.16)",
  color: "#fef3c7",
  fontWeight: "900",
};

const mainStyle = {
  minWidth: 0,
};

const vehicleStyle = {
  display: "block",
  color: "#ffffff",
  fontSize: "15px",
  marginBottom: "6px",
};

const summaryStyle = {
  margin: "0 0 10px 0",
  color: "#cbd5e1",
  lineHeight: "1.45",
  fontSize: "13px",
};

const tagsStyle = {
  display: "flex",
  gap: "8px",
  flexWrap: "wrap",
};

const tagStyle = {
  padding: "6px 9px",
  borderRadius: "999px",
  background: "rgba(56,189,248,0.12)",
  border: "1px solid rgba(56,189,248,0.2)",
  color: "#bae6fd",
  fontSize: "12px",
  fontWeight: "800",
};

const sellSpeedStyle = {
  marginTop: "12px",
  padding: "10px 12px",
  borderRadius: "14px",
  background: "rgba(34,197,94,0.10)",
  border: "1px solid rgba(34,197,94,0.20)",
  color: "#bbf7d0",
  fontSize: "12px",
  fontWeight: "800",
};

const reasonsStyle = {
  display: "grid",
  gap: "6px",
  marginTop: "12px",
};

const reasonStyle = {
  color: "#bbf7d0",
  fontSize: "12px",
  fontWeight: "800",
};

const scoreBoxStyle = {
  textAlign: "right",
  minWidth: "115px",
};

const actionStyle = {
  display: "block",
  color: "#bbf7d0",
  fontSize: "14px",
  marginBottom: "4px",
};

const scoreStyle = {
  display: "block",
  color: "#fef3c7",
  fontWeight: "900",
  fontSize: "18px",
};

const scoreLabelStyle = {
  color: "#94a3b8",
  fontSize: "11px",
  fontWeight: "800",
};

const speedBoxStyle = {
  marginTop: "12px",
  paddingTop: "10px",
  borderTop: "1px solid rgba(148,163,184,0.18)",
};

const speedScoreStyle = {
  display: "block",
  color: "#bbf7d0",
  fontWeight: "900",
  fontSize: "16px",
};

const emptyTextStyle = {
  color: "#94a3b8",
  margin: 0,
};